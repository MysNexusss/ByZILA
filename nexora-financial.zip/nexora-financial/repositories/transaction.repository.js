/**
 * transaction.repository.js
 * ============================================================================
 * Camada de acesso a dados — consultas cruas à tabela "transactions" no
 * Supabase. Não contém regras de negócio (isso pertence a
 * services/transaction.service.js).
 *
 * Responsabilidades futuras:
 *  - findAll(filtros)
 *  - findById(id)
 *  - insert(dados)
 *  - update(id, dados)
 *  - remove(id)
 *
 * Status: 🚧 Não implementado — fase atual: App Shell (arquitetura).
 * Depende de: supabase.js
 * ============================================================================
 */
